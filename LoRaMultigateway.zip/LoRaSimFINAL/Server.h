//
// This file is part of an OMNeT++/OMNEST simulation example.
//
// Copyright (C) 1992-2015 Andras Varga
//
// This file is distributed WITHOUT ANY WARRANTY. See the file
// `license' for details on this and other legal matters.
//

//25/11/2017

#ifndef __LORA_SERVER_H_
#define __LORA_SERVER_H_

#include <omnetpp.h>

#include "loraPacket_m.h"

using namespace omnetpp;

namespace aloha{

/**
 * Aloha server; see NED file for more info.
 */


class Server : public cSimpleModule
{
  private:
    // state variables, event pointers

    cMessage *endRxEvent;
    simtime_t endReceptionTime;
    simtime_t recvStartTime;
    int chFreqIndex;
    int chSFIndex;

    double receiveCounter;
    long rcvCounter[7]={0};
    long currentCollisionNumFrames[7]={0};
    long noOfCollidedPackets[7]={0};

    long successPackets[7]={0};
    double successRate[7]= {0};
    double successProb[7]={0};
    cOutVector successRateVector;

    struct receptionEvents
    {
        int chFreqIndex;
        int chSFIndex;
        simtime_t endReceptionTime ;
    };

    std::vector<receptionEvents> buffRxEvents;

    enum { IDLE = 0, TRANSMISSION = 1, COLLISION = 2 };
    simsignal_t channelStateSignal;

    // statistics
//    simsignal_t receiveBeginSignal;
//    simsignal_t receiveSignal;
//    simsignal_t collisionLengthSignal;
//    simsignal_t collisionSignal;

    double pathlossExp;
    int BW;
    double netR;

    double* pEstimateServiceRadius;
    double* pTotalAreaSFTier;
    double* pRelativeDensity;
    long* pNoOfHostsInEachSFTier;
    int nbOfChannels;

    double installedServerChannels[8][7] = {{868.1},{868.3},{868.5},{867.1},{867.3},{867.5},{867.7},{867.9}};

  public:
    Server();
    virtual ~Server();
    int getSF(double distance);


  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
    virtual void finish() override;
    virtual void refreshDisplay() const override;

    double *estimateServiceRadius(int BW, double pathlossExp, double netR);
    double *totalAreaSFTier(double estimateServiceRadius[]);
    double *relativeDensity(double totalAreaSFTier[]);
    long *noOfHostsInEachSFTier();

    void addRxEvent(int chFreqIndex, int chSFIndex, simtime_t endReceptionTime);
    void removeRxEvent(std::vector<receptionEvents> &buffRxEvents, simtime_t endReceptionTime);
    void printInstalledServerChannelsTable();
    void printRxEventsBuffer();
    void printRcvCounter();
    void printNoOfCollidedPackets();
    void printNoOfSuccessPackets();
    void printSuccessRate();

};

}; //namespace

#endif

