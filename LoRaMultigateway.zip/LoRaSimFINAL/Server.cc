//
// This file is part of an OMNeT++/OMNEST simulation example.
//
// Copyright (C) 1992-2015 Andras Varga
//
// This file is distributed WITHOUT ANY WARRANTY. See the file
// `license' for details on this and other legal matters.
//

#include "Server.h"
#include <algorithm>
namespace aloha {

Define_Module(Server);

Server::Server()
{
    endRxEvent = nullptr;

}

Server::~Server()
{
    cancelAndDelete(endRxEvent);
    delete pEstimateServiceRadius;
    delete pTotalAreaSFTier;
    delete pRelativeDensity;

}

void Server::initialize()
{
    channelStateSignal = registerSignal("channelState");
    endRxEvent = new cMessage("end-reception");
    endRxEvent->addPar("chFreqIndex");
    endRxEvent->addPar("chSFIndex");


    nbOfChannels = par("nbOfChannels");

    //emit(channelStateSignal, IDLE);

    gate("in")->setDeliverOnReceptionStart(true);
    successRateVector.setName("successRate9");


    //currentCollisionNumFrames = 0;
    //receiveCounter ={0};
    //currentCollisionNumFrames = {0};
    //rcvCounter = {0};
    //WATCH(currentCollisionNumFrames);

    //receiveBeginSignal = registerSignal("receiveBegin");
    //receiveSignal = registerSignal("receive");
    //collisionSignal = registerSignal("collision");
    //collisionLengthSignal = registerSignal("collisionLength");

    //emit(receiveSignal, 0L);
    //emit(receiveBeginSignal, 0L);


    getDisplayString().setTagArg("p", 0, par("x").doubleValue());
    getDisplayString().setTagArg("p", 1, par("y").doubleValue());

    // Estimating service radius
    BW = par("BW");
    pathlossExp = par("pathlossExp");
    netR = par("netR");
    pEstimateServiceRadius = estimateServiceRadius(BW, pathlossExp, netR);

    EV << "estimatedServiceRadius 7 : " << pEstimateServiceRadius[0] <<endl;
    EV << "estimatedServiceRadius 8 : " << pEstimateServiceRadius[1] <<endl;
    EV << "estimatedServiceRadius 9 : " << pEstimateServiceRadius[2] <<endl;
    EV << "estimatedServiceRadius 10 : " << pEstimateServiceRadius[3] <<endl;
    EV << "estimatedServiceRadius 11: " << pEstimateServiceRadius[4] <<endl;
    EV << "estimatedServiceRadius 12 : " << pEstimateServiceRadius[5] <<endl;
    receiveCounter = 0;
    //you want these lines to be drawn once only at initialize phase!
    for(int i = 5; i>=0; i--)
    {
        //displaying estimated service radii in GUI
        //std::string s = "r"+ std::to_string(i);
        //char const *pchar = s.c_str();
        char const *pchar = ("r"+ std::to_string(i)).c_str();
        getDisplayString().setTagArg(pchar, 0, pEstimateServiceRadius[i]);
    }

    pTotalAreaSFTier = totalAreaSFTier(pEstimateServiceRadius);

    pRelativeDensity = relativeDensity(pTotalAreaSFTier);

    pNoOfHostsInEachSFTier =noOfHostsInEachSFTier();
EV << "noofhostsinsftier 7 : " << pNoOfHostsInEachSFTier[0] <<endl;
EV << "noofhostsinsftier 8 : " << pNoOfHostsInEachSFTier[1] <<endl;
EV << "noofhostsinsftier 9 : " << pNoOfHostsInEachSFTier[2] <<endl;
EV << "noofhostsinsftier 10 : " << pNoOfHostsInEachSFTier[3] <<endl;
EV << "noofhostsinsftier 11: " << pNoOfHostsInEachSFTier[4] <<endl;
EV << "noofhostsinsftier 12 : " << pNoOfHostsInEachSFTier[5] <<endl;

}

void Server::handleMessage(cMessage *msg)
{
    if (msg->isSelfMessage()) { //multiple endRxEvents received from different streams!! (each endRxEvent has different parameters)
        int msgRxChFreqIndex = msg->par(0).doubleValue()  ;
        int msgRxChSFIndex = msg->par(1).doubleValue();
        simtime_t msgRxChEndRxTime = msg->getTimestamp();
        //simtime_t msgRxChEndRxTime = msg->par(2).doubleValue();
        EV << "SELF MESSAGE : " <<endl;
        EV << "reception finished on channel: " << msgRxChFreqIndex<<"-" <<msgRxChSFIndex << "@sim time: " << simTime()<< "same as stamped time?:) " << msg->getTimestamp()<< "\n";
        installedServerChannels[msgRxChFreqIndex][msgRxChSFIndex]--;
        printNoOfCollidedPackets();

        if (installedServerChannels[msgRxChFreqIndex][msgRxChSFIndex] < 0)
            throw cRuntimeError ("Error using installed server channels!");
        printInstalledServerChannelsTable();

        EV << "deleting the entry from the event table:)" <<endl;
        removeRxEvent(buffRxEvents, msgRxChEndRxTime);
        printRxEventsBuffer();

        if (!buffRxEvents.empty())
        {
            cancelEvent(endRxEvent);
            endRxEvent->par(0) = (buffRxEvents).front().chFreqIndex;
            endRxEvent->par(1) = (buffRxEvents).front().chSFIndex;
            endRxEvent->setTimestamp((buffRxEvents).front().endReceptionTime);
            //endRxEvent->par(2) = (buffRxEvents).front().endReceptionTime.dbl();
            EV << "Prior scheduled endRxEvents in buff, rescheduling the next one @ t= " << (buffRxEvents).front().endReceptionTime <<endl;
            scheduleAt((buffRxEvents).front().endReceptionTime, endRxEvent);
        }

        if (currentCollisionNumFrames[msgRxChSFIndex] >0)
        currentCollisionNumFrames[msgRxChSFIndex] --;
        //currentCollisionNumFrames[msgRxChSFIndex] =0;
        EV << "currentCollisionNumOfFrames: " <<endl;
        for (int i =0; i<=6; i++)
        {
        EV <<  currentCollisionNumFrames[i]<< "|";
        }
        EV  <<endl;
    }
    else {
        loraPacket *pkt = check_and_cast<loraPacket *>(msg);

        ASSERT(pkt->isReceptionStart());

        //channel on which this packet is received on: Ch. represented by a pair of used attributes (SF, ch. freq.)
        int pktSF = pkt->getSF();
        double pktChFreq = pkt->getChFreq();

        EV <<  pkt->getName()<< "arrived on t= "<<pkt->getArrivalTime()  << "|| using channel (SF:"  << pktSF<< "-chFreq:" << pktChFreq<< ")"<<endl;

        //find this channel index on installed server channels - which are the attributes to endRxEvent msg to end that stream!
        bool findChCheck = false;
        int i = 0;
        while (findChCheck == false && i< nbOfChannels)
        {
            if (installedServerChannels[i][0] == pktChFreq)
            {
                findChCheck = true;
                chFreqIndex = i;
                chSFIndex = pktSF - 6;
            }
            i++;
        }
        if (findChCheck == false)
            throw cRuntimeError("Channel Freq. not installed on this server");

        endReceptionTime = simTime() + pkt->getDuration();
        EV << "Adding recevingEvent in Buffer " << endl;
        addRxEvent(chFreqIndex, chSFIndex, endReceptionTime); //sorted according to minimum endReceptionTime of each event
        receiveCounter++;
        rcvCounter[chSFIndex]++;
        printRcvCounter();
        EV <<  "receiveCounter: " << receiveCounter <<endl;
        EV << "endReceptionTime: " << endReceptionTime << endl;

        //emit(receiveBeginSignal, ++receiveCounter);
        recvStartTime = simTime();

        if (installedServerChannels[chFreqIndex][chSFIndex] ==0) {
            EV << "Start receiving on channel:" <<chFreqIndex <<"-"<<chSFIndex <<"\n";


            //do so and so for statistics!!

            //recvStartTime = simTime();

            //channelBusy = true;
            //installedServerChannels[chFreqIndex][chSFIndex]++;

            //emit(channelStateSignal, TRANSMISSION);
            //scheduleAt(endReceptionTime, endRxEvent);


        }
        else if (installedServerChannels[chFreqIndex][chSFIndex] >0) {
            EV << "Another frame arrived while receiving -- collision on this channel (" <<pktChFreq<< "/" << pktSF<< ")\n";

            // throw cRuntimeError ("COLLISION");

            //do so and so for statistics!!
//            if (installedServerChannels[msgRxChFreqIndex][msgRxChSFIndex] >0 )
//            {

//            }
            //emit(channelStateSignal, COLLISION);
            //
            //            //needs to cross multiply kolo now!!
            if (currentCollisionNumFrames[chSFIndex] == 0)
            {
                currentCollisionNumFrames[chSFIndex] = 2;
                noOfCollidedPackets[chSFIndex] = noOfCollidedPackets[chSFIndex] + 2;
            }
                else
                {
                currentCollisionNumFrames[chSFIndex]++;
                noOfCollidedPackets[chSFIndex]++;
                }
//            if (currentCollisionNumFrames[chSFIndex] >2)
//                throw cRuntimeError ("CHECK THIS!") ;
            EV << "currentCollisionNumOfFrames: " <<endl;
            for (int i =0; i<=6; i++)
            {
            EV <<  currentCollisionNumFrames[i]<< "|";
            }
            EV  <<endl;

            if (noOfCollidedPackets[chSFIndex] > rcvCounter[chSFIndex])
                throw cRuntimeError( "no. of collided packets? akbar men el received.. check this event");
            //printRcvCounter();
            //printNoOfCollidedPackets();
            //printNoOfSuccessPackets();
            //noOfCollidedPackets[msgRxChSFIndex] = currentCollisionNumFrames[msgRxChSFIndex] + (installedServerChannels[msgRxChFreqIndex][msgRxChSFIndex] - currentCollisionNumFrames[msgRxChSFIndex]);
            //EV << "There are " << installedServerChannels[msgRxChFreqIndex][msgRxChSFIndex] << "collided!" <<endl;
            printNoOfCollidedPackets();

            // update network graphics
            if (hasGUI()) {
                char buf[32];
                sprintf(buf, "Collision!");
                //sprintf(buf, "Collision! %frames-%d-%d", installedServerChannels[chFreqIndex][chSFIndex] , pktChFreq, pktSF);
                //sprintf(buf, "Collision! (%ld frames)", currentCollisionNumFrames);
                bubble(buf);
               // getParentModule()->getCanvas()->holdSimulationFor(par("animationHoldTimeOnCollision"));
            }
        }

        EV << "scheduling next endRxEvent:" <<endl;
        if (!buffRxEvents.empty() && endReceptionTime !=0) {
            cancelEvent(endRxEvent);
            printRxEventsBuffer();
            endRxEvent->par(0) = (buffRxEvents).front().chFreqIndex;
            endRxEvent->par(1) = (buffRxEvents).front().chSFIndex;
            endRxEvent->setTimestamp((buffRxEvents).front().endReceptionTime);
            scheduleAt((buffRxEvents).front().endReceptionTime, endRxEvent);
        }


        installedServerChannels[chFreqIndex][chSFIndex]++;
        printInstalledServerChannelsTable();
        delete pkt;
    }
}


void Server::refreshDisplay() const
{
    //    //you want these lines to be drawn once only at initialize phase!
    //    for(int i = 5; i>=0; i--)
    //    {
    //        //displaying estimated service radii in GUI
    //        //std::string s = "r"+ std::to_string(i);
    //        //char const *pchar = s.c_str();
    //        char const *pchar = ("r"+ std::to_string(i)).c_str();
    //        EV << " printing keda eh??:)  " << pEstimateServiceRadius[i] <<endl;
    //        getDisplayString().setTagArg(pchar, 0, pEstimateServiceRadius[i]);
    //    }

    //    if (installedServerChannels[chFreqIndex][chSFIndex] >0){
    //    //if (!channelBusy) {
    //        getDisplayString().setTagArg("i2", 0, "status/off");
    //        getDisplayString().setTagArg("t", 0, "");
    //    }
    //    else if (currentCollisionNumFrames == 0) {
    //        getDisplayString().setTagArg("i2", 0, "status/yellow");
    //        getDisplayString().setTagArg("t", 0, "RECEIVE");
    //        getDisplayString().setTagArg("t", 2, "#808000");
    //    }
    //    else {
    //        getDisplayString().setTagArg("i2", 0, "status/red");
    //        getDisplayString().setTagArg("t", 0, "COLLISION");
    //        getDisplayString().setTagArg("t", 2, "#800000");
    //    }
}

void Server::finish()
{
    double totalSuccessRate = 0;
    double totalSuccessProb = 0;
    double totalSuccessPackets = 0;

    EV << "totalReceiveCounter: " << receiveCounter <<endl;

        for (int i =1; i <=6; i++)
        {

            successPackets[i] = rcvCounter[i] - noOfCollidedPackets[i];
            successRate[i] =successPackets[i]/simTime() ;
            successProb[i] = successPackets[i] / receiveCounter;
            char buf[32];
            sprintf(buf, "SF: %i",i+6);
            recordScalar(buf, successRate[i]);

            char buf1[32];
            sprintf(buf1, "rcvCounter: %i",i+6);
            recordScalar(buf1, rcvCounter[i]);

            char buf2[32];
            sprintf(buf2, "noOfCollidedPackets: %i",i+6);
            recordScalar(buf2, noOfCollidedPackets[i]);

            char buf3[32];
            sprintf(buf3, "noOfSuccessPackets: %i",i+6);
            recordScalar(buf3, successPackets[i]);

            char buf4[32];
            sprintf(buf4, "noOfHostsInSFTier: %i",i+6);
            recordScalar(buf4, pNoOfHostsInEachSFTier[i-1]);

            totalSuccessPackets = totalSuccessPackets + successPackets[i];
            totalSuccessRate = totalSuccessRate + successRate[i];
            totalSuccessProb = totalSuccessProb + successProb[i];

        }

        printRcvCounter();
        printNoOfCollidedPackets();
        printNoOfSuccessPackets();
        printSuccessRate();

    successRate[0] = totalSuccessRate;
    successProb[0] = totalSuccessProb;
    recordScalar("totalSuccessRate", totalSuccessRate);
    recordScalar("totalSuccessProb", totalSuccessProb);
    EV << "totalSuccessRate = " << successRate[0]<<endl;
    EV << "totalSuccessProb = " << successProb[0]<<endl;

    EV << "doublecheckSuccProb = " << totalSuccessPackets/receiveCounter <<endl;
    EV << "duration: " << simTime() << endl;
    EV << "noOfHostsinSFTier SF7 : " << pNoOfHostsInEachSFTier[0]<<endl;
    EV << "noOfHostsinSFTier SF8 : " << pNoOfHostsInEachSFTier[1]<<endl;
    EV << "noOfHostsinSFTier SF9 : " << pNoOfHostsInEachSFTier[2]<<endl;
    EV << "noOfHostsinSFTier SF10 : " << pNoOfHostsInEachSFTier[3]<<endl;
    EV << "noOfHostsinSFTier SF11 : " << pNoOfHostsInEachSFTier[4]<<endl;
    EV << "noOfHostsinSFTier SF12 : " << pNoOfHostsInEachSFTier[5]<<endl;
    recordScalar("duration", simTime());
}

void Server::addRxEvent(int chFreqIndex, int chSFIndex, simtime_t endReceptionTime)
{// this function creates a new endRxEvent and adds it in the buffer in a sorted fashion according to minimum
    //end reception time to be rescheduled next and free it's channel
    receptionEvents newEvent;
    newEvent.chFreqIndex = chFreqIndex;
    newEvent.chSFIndex = chSFIndex;
    newEvent.endReceptionTime = endReceptionTime;

    buffRxEvents.push_back(newEvent);
    if(!buffRxEvents.empty())
        sort(buffRxEvents.begin(),buffRxEvents.end(), [](const receptionEvents &a, const receptionEvents &b) {return (a.endReceptionTime < b.endReceptionTime);});
}

void Server::removeRxEvent(std::vector<receptionEvents> &buffRxEvents, simtime_t endReceptionTime)
{
    buffRxEvents.erase(
            std::remove_if(buffRxEvents.begin(), buffRxEvents.end(), [&](receptionEvents const & tmp){
        return tmp.endReceptionTime == endReceptionTime;

    }),
    buffRxEvents.end());
}

void Server::printRxEventsBuffer()
{
    if(!buffRxEvents.empty())

    {
        EV<< "rxEventBuffer:" <<endl;
        for (unsigned int count = 0; count < buffRxEvents.size(); count++)
        {
            EV << buffRxEvents[count].chFreqIndex << " - " << buffRxEvents[count].chSFIndex << "- " << buffRxEvents[count].endReceptionTime << endl;
        }

    }
}

void Server::printRcvCounter()
{
    double checkTotalReceivedMessages=0;
    EV << "rcvCounter" <<endl;
    for (int i = 1; i <=6; i++)
    {
        EV <<  rcvCounter[i] << "|" ;
        checkTotalReceivedMessages = checkTotalReceivedMessages + rcvCounter[i];
    }
    EV << "checkTotalReceivedMessages" << checkTotalReceivedMessages << endl;
    EV << endl;
}

void Server::printNoOfCollidedPackets()
{
    EV << "noOfCollidedPackets: " <<endl;
    for (int i = 1; i <=6; i++)
    {
        EV <<  noOfCollidedPackets[i] << "|" ;
    }
    EV << endl;
}

void Server::printNoOfSuccessPackets()
{
    EV << "noOfSucessPackets: " <<endl;
    for (int i = 1; i <=6; i++)
    {
        EV <<  successPackets[i] << "|" ;
    }
    EV << endl;
}

void Server::printSuccessRate()
{
    EV << "sucessRate: " <<endl;
    for (int i = 1; i <=6; i++)
    {
        EV <<  successRate[i] << "|" ;
    }
    EV << endl;

}

double* Server::estimateServiceRadius(int BW, double pathlossExp, double netR)
{
    //this function takes BW (kHz) and pathlossexponent as inputs,
    //calculates the sensitivity gap and return a pointer to an array
    //estimated service radius for each SF
    //pEstimatedServiceRadii

    double *estimateServiceRadius = new double[6]; //i think new here is needed? bec will be used by the host as well!??
    double *pEstimateServiceRadius;
    int *p;

    // sensitivity values for correct demodulation on SX1272/73 transceiver
    int sensitivity125[6] = {-124, -127, -130, -133, -135, -137};
    int sensitivity250[6] = {-122, -125, -128, -130, -132, -135};
    int sensitivity500[6] = {-116,-119,-122,-125,-128,-129};
    if (BW == 125)
        p = sensitivity125;
    else if (BW == 250)
        p = sensitivity250;
    else
        p = sensitivity500;

    int i = 5;
    estimateServiceRadius[i] = netR;

    while(i>0)
    {
        //calculated sensitivity gap
        int sensitivityGap = abs(p[i]-p[i-1]);

        //fixed sensitivity gap
        //int sensitivityGap = 3;
        estimateServiceRadius[i-1] = estimateServiceRadius[i]/pow(10,(sensitivityGap/(10*pathlossExp)));
        i--;
    }

    ///////////////////////// spring 2024
    estimateServiceRadius[0] = 2426.61;
    estimateServiceRadius[1]= 2939.91;
    estimateServiceRadius[2] = 3561.78;
    estimateServiceRadius[3] = 4315.19;
    estimateServiceRadius[4] = 5227.97;
    estimateServiceRadius[5] = 6333.83;
    ////////////////////////////
    return pEstimateServiceRadius = estimateServiceRadius;
}

double * Server::totalAreaSFTier(double estimateServiceRadius[])
{
    int i = 5;
    double *totalAreaSFTier = new double[6];
    double *pTotalAreaSFTier;
    while (i>0)
    {
        totalAreaSFTier[i] = 3.141593*((pEstimateServiceRadius[i]*pEstimateServiceRadius[i]) - (pEstimateServiceRadius[i-1]*pEstimateServiceRadius[i-1]));
        i--;
    }
    //EV <<" pEstimateServiceRadius[ " << i << "]:" <<pEstimateServiceRadius[i] <<endl;
    totalAreaSFTier[0] = 3.141593*(pEstimateServiceRadius[0]*pEstimateServiceRadius[0]);
    //EV << "FUNC:totalAreaSFTier[" << i << "]: " << totalAreaSFTier[i]<<endl;
    return pTotalAreaSFTier = totalAreaSFTier;
}

double* Server::relativeDensity(double pTotalAreaSFTier[])
{
    double *relativeDensity = new double[6];


    //    double totalAreaCoveredByBS = 0;
    //
    //    for(int i=5; i>=0;i--)
    //    {
    //                totalAreaCoveredByBS+= pTotalAreaSFTier[i];
    //    }

    //SF Tier Area/ Total Area =)
    double totalAreaCoveredByBS = 3.14159*netR*netR; //this is equivalant to total areas for each SF tier area

    for(int i=5;i>=0;i--)
    {
        relativeDensity[i] = pTotalAreaSFTier[i]/ totalAreaCoveredByBS;
        EV << "RelativeDensity of " << i << " ="<< relativeDensity[i] <<endl;
    }


    pRelativeDensity = relativeDensity;
    return pRelativeDensity;

}

long * Server::noOfHostsInEachSFTier()
{   //this function returns the number of hosts allocated in each SF tier

    int netR = par("netR").doubleValue();
    long *nbOfHostsInSFTier = new long[6] {0,0,0,0,0,0};
    int nbOfConnectedHosts = 0;
    bool reachedLastHost = false;
    while (reachedLastHost == false)
    {
        char buf[20];
        sprintf(buf, "host[%d]",  nbOfConnectedHosts);
        //EV << "buf" << buf <<endl;
        cModule *host = getModuleByPath(buf);

        if (host!=nullptr)
        {
            ////Method1: retrieve the SF from the host itself!
            //int numHosts = host->getVectorSize();
            //Host *cHost = dynamic_cast<Host*>(host);
            // int SF = cHost->SF; // SF will need to be a public variable in the host module and server module need to #include "host.h"

            //Method2: calculates distance between host and server and get the SF equivalent to it!
            nbOfConnectedHosts++; //counting all hosts connected to the server
            double hostX = host->par("x").doubleValue();
            double hostY = host->par("y").doubleValue();
            double dist = std::sqrt((hostX-0) * (hostX-0) + (hostY-0) * (hostY-0));
            if (dist <= netR){
                EV << "dist" << dist <<endl;
                EV << "SF" << getSF(dist) <<endl;
                nbOfHostsInSFTier[getSF(dist)-7] ++;
            }
            else{
                nbOfHostsInSFTier[getSF(dist)-7] = nbOfHostsInSFTier[getSF(dist)-7];
            }
            EV << "nbOfHostsInSFTier[getSF(dist)-7]" << nbOfHostsInSFTier[getSF(dist)-7] <<endl;
        }
        else
        {
            reachedLastHost = true;
        }

    }
    pNoOfHostsInEachSFTier = nbOfHostsInSFTier;
    return pNoOfHostsInEachSFTier;

}

int Server:: getSF(double distance)
{
    //this is a public function accessed by each host to retrieve their equivalent SF from the gateway.
    //N.B.: SF retrieved based on calculated distance away from Base-station
    //and assuming that each tier includes ONLY hosts of their perspective SF (TODO: better documentation)

    int indexEstimateServiceRadius = 5; // nodes will always be assigned SF12 if they fall out of network radius
    //int indexEstimateServiceRadius = 100; // nodes falling out of net. radius will be signaled an error!
    for (int i = 0; i<=5; i++)
    {
        if (distance <= pEstimateServiceRadius[i])
        {
            indexEstimateServiceRadius = i;
            break;
        }
    }
    int SF = indexEstimateServiceRadius + 7;
    return SF;
}

void Server::printInstalledServerChannelsTable()
{
    for (int i=0; i<nbOfChannels;i++)
    {
        for(int j=0; j<7;j++)
        {
            EV << "| " << installedServerChannels[i][j] ;
        }
        EV << endl;
    }
}
}; //namespace


