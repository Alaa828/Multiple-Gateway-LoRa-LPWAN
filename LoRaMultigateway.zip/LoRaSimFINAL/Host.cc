//
// This file is part of an OMNeT++/OMNEST simulation example.
//
// Copyright (C) 1992-2015 Andras Varga
//
// This file is distributed WITHOUT ANY WARRANTY. See the file
// `license' for details on this and other legal matters.
//

#include <algorithm>
#include <vector>
#include "Host.h"

namespace aloha {

Define_Module(Host);

Host::Host()
{
    endEvent = nullptr;
}

Host::~Host()
{
    delete lastPacket;
    cancelAndDelete(endEvent);
}

// Map to store the set of hosts connected to each server
std::map<cModule*, std::set<int>> connectedHostsPerServer;
std::map<int, std::map<int, int>> hostsPerServerPerSF;
std::set<int> hostsNotCoveredByAnyServer;

void Host::initialize()
{

    EV << "Initializing Host module. Checking server modules..." << endl;
    int nbOfConnectedServers = 0;
    bool reachedLastServer = false;
    while (reachedLastServer == false)
    {
        char buf[20];
        sprintf(buf, "server[%d]",  nbOfConnectedServers);
        //EV << "buf" << buf <<endl;
        cModule *server = getModuleByPath(buf);

        if (server != nullptr)
        {
            nbOfConnectedServers++;
            double serverX = server->par("x").doubleValue();
            double serverY = server->par("y").doubleValue();
            double dist = std::sqrt((serverX-0) * (serverX-0) + (serverY-0) * (serverY-0));
            radioDelay = dist / propagationSpeed;

            Server *cServer = dynamic_cast<Server*>(server);
            SF = cServer->getSF(dist); //attained from the gateway

            EV << server << endl;

         } else {
             reachedLastServer = true;
             EV << "Reached the last server module." << endl;
         }
    }

    pkLenBits = &par("pkLenBits") ;
    iaTime = &par("iaTime");
    slotTime = par("slotTime");
    isSlotted = slotTime > 0;
    bufferedPkts = 0;
    isBufferingEvents = par("isBufferingEvents");
    addFrameHeader = par("addFrameHeader");
    if (addFrameHeader == true)
        frameLenBits = pkLenBits->longValue() +(13*8);
    else
        frameLenBits = pkLenBits->longValue();
    dutyCycleActive = par("dutyCycleActive");

    endEvent = new cMessage("endState");
    state = IDLE;
    pkCounter = 0;
    WATCH((int&)state);
    WATCH(pkCounter);

    r =par("r").doubleValue();
    theta = par("theta").doubleValue();
    x = par("x").doubleValue();
    y = par("y").doubleValue();

    idleAnimationSpeed = par("idleAnimationSpeed");
    transmissionEdgeAnimationSpeed = par("transmissionEdgeAnimationSpeed");
    midtransmissionAnimationSpeed = par("midTransmissionAnimationSpeed");

    getDisplayString().setTagArg("p", 0, x);
    getDisplayString().setTagArg("p", 1, y);

    //Display parameters to visualize different apps running on each end-device!
    if (pkLenBits->longValue() >8)
        getDisplayString().setTagArg("i", 1, "red");
    else
        getDisplayString().setTagArg("i", 1, "blue");

    //scheduling 1st transmission

    //fn of host id
    //simtime_t firstTx = uniform(0,getId());

    //fn. of the app iaTime
    //(rand()%(iaTime->doubleValue())

    //getTxTime w khalas??
    simtime_t firstTx = getNextTransmissionTime();

    scheduleAt( firstTx, endEvent);

    nbOfChannels = par("nbOfChannels");
    BW = par("BW");
    CR = par("CR");

    //End-device behaviour for SF Selection:
    //SF = intuniform(7,cServer->getSF(dist));
    //if (SF > 12 ) EV << "Out of Network Radius!" <<endl; //TODO: check what to do with nodes out of range!
    //else  EV <<  "SF" << SF <<endl;

    txRate = SF * (BW/std::pow(2,SF))* CR;
    nbOfBusyChannels = 0;

    EV << "pkt size in bits: " <<frameLenBits <<endl;
    EV<< "1st Tx. Time: " << firstTx <<endl;
    EV << "iaTime: " << &iaTime <<endl;


    if (pkLenBits->doubleValue() > 8)
        getParentModule()->getDisplayString().setTagArg("i", 1, "yellow");
    else
        getParentModule()->getDisplayString().setTagArg("i", 1, "red");
}

void Host::handleMessage(cMessage *msg)
{
    ASSERT(msg == endEvent);

    //animation and display
    //getParentModule()->getCanvas()->setAnimationSpeed(transmissionEdgeAnimationSpeed, this);

    if (state == IDLE) {
        EV <<  "END OF IDLE STATE" <<endl;
        printInstalledChannelsTable();


        // generate packet and schedule timer when it ends
        char pkname[40];
        sprintf(pkname, "pk-%d-#%d", getId(), pkCounter++);

        state = TRANSMIT;

        loraPacket *pk = new loraPacket(pkname);
        pk->setBitLength(frameLenBits);
        pk->setSF(SF);

        simtime_t duration = pk->getBitLength() / txRate;
        int channel = selectAvailableChannel(duration); //Available
        pk->setChFreq(installedChannels[channel][1]);

        EV << "generating packet " << pkname << " -SF: " << pk->getSF() << " -ch. Freq.: " << pk->getChFreq() <<endl;
        EV << "pkt duration: " << duration <<endl;

        // Get the number of servers
        int numServers = getParentModule()->par("numServers");

        // Find the closest server
        double minDistance = std::numeric_limits<double>::max();
        cModule *closestServer = nullptr;
        for (int i = 0; i < numServers; ++i) {
            char buf[20];
            sprintf(buf, "server[%d]", i);
            cModule *server = getModuleByPath(buf);
            if (server != nullptr) {
                double serverX = server->par("x").doubleValue();
                double serverY = server->par("y").doubleValue();
                double distance = std::sqrt(std::pow(x - serverX, 2) + std::pow(y - serverY, 2));
                if (distance < minDistance) {
                    minDistance = distance;
                    closestServer = server;
                }
            }
        }

        // Check if a closest server was found
        if (closestServer != nullptr) {
            // Check if the distance is within the threshold
            if (minDistance <= 6333.83) {
                // Increment the count of connected hosts for the closest server
                int serverIndex = closestServer->getIndex();
                if (connectedHostsPerServer[closestServer].count(getIndex()) == 0) {
                    connectedHostsPerServer[closestServer].insert(getIndex());
                    // Update visualization or other actions as needed
                    // Determine the spreading factor
                    int sf = -1; // Initialize to an invalid value
                    if (minDistance <= 2426.61) {
                        sf = 7;
                    } else if (minDistance <= 2939.91) {
                        sf = 8;
                    } else if (minDistance <= 3561.78) {
                        sf = 9;
                    } else if (minDistance <= 4315.19) {
                        sf = 10;
                    } else if (minDistance <= 5227.97) {
                        sf = 11;
                    } else {
                        sf = 12;
                    }
                    // Increment the count of hosts connected to the server at the determined spreading factor
                    // Only count the server for this spreading factor if it hasn't been counted before
                    hostsPerServerPerSF[serverIndex][sf]++;
                }
                // Send message to the closest server
                sendDirect(pk->dup(), radioDelay, duration, closestServer->gate("in"));
                EV_INFO << "Message sent to Server[" << serverIndex << "]." << endl;
            } else {
                hostsNotCoveredByAnyServer.insert(getIndex());
                delete pk; // Drop the packet
                // Track not covered hosts
            }
        } else {
            EV_ERROR << "No server found." << endl;
            delete pk;
        }
        int numHosts = getParentModule()->par("numHosts");

        // Print the number of connected hosts for each server
        EV_INFO << "Number of connected hosts and percentage for each server:" << endl;
        for (auto& pair : connectedHostsPerServer) {
            int serverIndex = pair.first->getIndex();
            int numOfConnectedHosts = pair.second.size();
            double percentage = (static_cast<double>(numOfConnectedHosts) / numHosts) * 100.0;
            EV_INFO << "Server[" << serverIndex << "]: Number of connected hosts = " << numOfConnectedHosts << endl;
            EV_INFO << "Server[" << serverIndex << "]: Percentage of connected hosts = " << percentage << "%" << endl;
        }
        EV_INFO << "Number of hosts not covered by any server: " << hostsNotCoveredByAnyServer.size() << endl;
        double percentageNotCoveredByAnyServer = (static_cast<double>(hostsNotCoveredByAnyServer.size()) / numHosts) * 100.0;
        EV_INFO << "Percentage of hosts not covered by any server: " << percentageNotCoveredByAnyServer << "%" << endl;







        //check if any channels will be free during transmission and update installed channels
        //lw fee aii endToff < simTime()+duration
        double minEndTOff = getMinEndTOff();
//        double minEndTOff = installedChannels[0][2];
//        for (int i =0; i < nbOfChannels; i++)
//        {
//            if (installedChannels[i][2] < minEndTOff)
//                minEndTOff = installedChannels[i][2];
//        }

        EV << "Time for packet to finish transmission::::" << simTime()+duration <<endl;
        simtime_t tmp = minEndTOff;
       //if ((minEndTOff <= (simTime()+duration).dbl()) && (minEndTOff !=0) )
        if ((tmp <= (simTime()+duration)) && (tmp !=0))
        {

            for(int i=0;i < nbOfChannels ; i++)
            {
                if (installedChannels[i][2] == minEndTOff)
                {
                //EV << "will see loop: " << installedChannels[i][2] <<endl;
                //EV << "minEndTOff" << minEndTOff <<endl;
                installedChannels[i][2] = 0 ;
                nbOfBusyChannels--;
                }
            }
            printInstalledChannelsTable();
        }


        if (bufferedPkts > 0 ) bufferedPkts--;

        scheduleAt(simTime()+duration, endEvent);

        // let visualization code know about the new packet
        if (transmissionRing != nullptr) {
            delete lastPacket;
            lastPacket = pk->dup();
        }
        printInstalledChannelsTable();
        EV <<  "//IDLE STATE" <<endl;
    }
    else if (state == TRANSMIT) {
        // endEvent indicates end of transmission
        //check if all channels are busy -> go to state (WAITINGFORCH), if not -> go to state (IDLE)
        EV <<  "END OF TRANSMIT STATE" <<endl;

        printInstalledChannelsTable();

        nextTransmissionTime = getNextTransmissionTime();

        EV << "next time to schedule a packet?:) " << nextTransmissionTime <<endl;

        if (nbOfBusyChannels == nbOfChannels) //no av. channels
        {
            EV << "nbOfBusyChannels == nbOfChannels --> NO. AV. Ch --> waiting for ch. free" <<endl;
            state = WAITINGFORCH;
            //emit(stateSignal, state);

            //all channels are busy (in their Toff)
            // find minimum endToff: time for a sub-band to be free
            double minEndTOff = getMinEndTOff();
//            double minEndTOff = installedChannels[0][2];
//            for (int i =0; i < nbOfChannels; i++)
//            {
//                if (installedChannels[i][2] < minEndTOff)
//                    minEndTOff = installedChannels[i][2];
//            }


            //check if any packets will be generated while host will be busy waiting for a channel!
            if (nextTransmissionTime < minEndTOff) // < walla <=
            {//make sure to send directly asa a ch is free
                bufferedPkts++ ;
                //EV << "bufferedPkts" << bufferedPkts <<endl;
            }
            scheduleAt(minEndTOff, endEvent);

            printInstalledChannelsTable();
            EV <<  "//TRANSMIT STATE - when all channels are busy" <<endl;
        }
        else if (nbOfBusyChannels < nbOfChannels)
        {//there are some free channels to use and so you can transmit!
            EV << "nbOfBusyChannels < nbOfChannels --> YES AV. CH --> you are going to be idle" <<endl;
            state = IDLE;
            scheduleAt(nextTransmissionTime, endEvent);

            printInstalledChannelsTable();
            EV <<  "//TRANSMIT STATE - when some channels are still free" <<endl;
        }
    }
    else if (state == WAITINGFORCH) {
        //endEvent indicates end of waiting time of a channel
        EV << "END OF WAITINGFORCH STATE" << endl;
        state = IDLE;

        //update data structure of installed channels by freeing their endToff!! and decrementing nbOfBusyChannels
        for(int i=0;i < nbOfChannels ; i++)
        {
            //if (std::to_string(installedChannels[i][2]) <= std::to_string(simTime().dbl()))//both converted to strings because sometime converting to double loses precision and yields wrong results
            //if (std::to_string(installedChannels[i][2]) == std::to_string(simTime().dbl()) || installedChannels[i][2] < simTime().dbl())
            simtime_t tmp = installedChannels[i][2];

            //if (installedChannels[i][2] <= simTime().dbl())
            if (tmp <= simTime())
            {
//                EV << " installedChannels[i][2] - gowa el if" << std::to_string(installedChannels[i][2]) <<endl;
                installedChannels[i][2] = 0 ;
                nbOfBusyChannels--;
            }
        }
        //schedule sending after checking if there are any buffered pkts
         //scheduleAt(getNextTransmissionTime(), endEvent);//TODODONE: check if u should remove that!
        if (bufferedPkts > 0 && isBufferingEvents ==true)
        {
            scheduleAt(simTime(), endEvent);
//            EV << "bufferedPkts" << bufferedPkts <<endl;
        }
        else{
            scheduleAt(getNextTransmissionTime(), endEvent);
        }

        printInstalledChannelsTable();
        EV <<  "//WAITINGFORCH STATE" <<endl;
    }
    else {
        throw cRuntimeError("invalid state");
    }
}

simtime_t Host::getNextTransmissionTime()
{
    simtime_t t = simTime() + iaTime->doubleValue();

    if (!isSlotted)
        return t;
    else
        // align time of next transmission to a slot boundary
        return slotTime * ceil(t/slotTime);
}

int Host::selectAvailableChannel(simtime_t TOA)
{   //this function selects available channel and update installed channels data structure
    //this function takes packet duration (TOA) as input and returns a valid channel index number or 1000 if no channels are available
    //Method2.0: keeps track of nbofBusyChannels, if all are idle returns busy
    //if there is any free channel available.. randomly keep picking one out of all installed (free and busy) channels
    //when the free channel found: - Get channel sub-band and duty cycle of this sub-band.
    //                             - Calculate Toff and expected time for this sub-band Toff to end.
    //                             - Indicate each channel in corresponding sub-band is busy till the same endToff calculated and incrementing the count of nbOfBusyChannels
    //EV <<  "Selecting channel function: " <<endl;
    //printInstalledChannelsTable();
    //EV << "nbOfChannels:" << nbOfChannels <<endl;
    //EV << "nbOfBusyChannels:" << nbOfBusyChannels <<endl;

    int channel;
    if (nbOfBusyChannels <nbOfChannels) //make sure there is a free channel i.e.: wont loop here forever!
    {
        bool chFound = false;
        while (chFound ==false)
        {
            channel = uniform(0,nbOfChannels); //randomly pick any channel
            //EV << "Picked channel:" << channel <<endl;
            //EV << "endToff of it:" <<installedChannels[channel][2] <<endl;
            //EV << "current simtime: " << simTime().dbl() <<endl;
            if (installedChannels[channel][2] < simTime().dbl() ) //check if its free comparing current time endTOff
            {
                chFound = true;
                int chSubband = installedChannels[channel][0]; //channel sub-band
                //EV << "Duty cycle of subband of channel picked: " << dutyCycle[chSubband] <<endl; //duty cycle of this sub-band

                if (dutyCycleActive == false)
                {
                    //  deactivating the effect of Toff
                    simtime_t endToff = simTime()+TOA;

                    if ( installedChannels[channel][2] > 0) nbOfBusyChannels--; //if its the same subband of a previously used channel (a previously used channel in case of Toff deactivated) -> free it up
                    installedChannels[channel][2] =endToff.dbl();
                    nbOfBusyChannels++;
                }
                else if (dutyCycleActive == true)
                {
                    simtime_t endToff = simTime() + ((TOA / dutyCycle[chSubband])  - TOA); //expected time for the Toff to end

                    for(int i=0;i < nbOfChannels ; i++) //apply this expected time for all channels of similar sub-band
                    {

                        if (installedChannels[i][0] == chSubband)
                        {
                            if ( installedChannels[i][2] > 0) nbOfBusyChannels--; //if its the same subband of a previously used channel -> free it up
                            installedChannels[i][2] = endToff.dbl() ;
                            //if (installedChannels[i][2] > 0)//update installed channels data structure &by recalculating nb of busy channels
                            nbOfBusyChannels++;
                        }
                    }
                }
            }
        }

        //EV <<"Found channel :) of number:  " << channel<< endl;
    }
    else
    { //all channels are busy (in their Toff)
        channel = 1000; //u r supposd to throw an error here!!
        throw cRuntimeError("invalid channel selection");
        //EV << "All channels are in their Toff!!" <<endl;
    }

    //EV <<  "Selecting channel function: " <<endl;
    //printInstalledChannelsTable();
    //EV << "nbOfChannels:" << nbOfChannels <<endl;
    //EV << "nbOfBusyChannels:" << nbOfBusyChannels <<endl;

    return channel;
}


void Host::refreshDisplay() const
{
//    cCanvas *canvas = getParentModule()->getCanvas();
//    const int numCircles = 20;
//    const double circleLineWidth = 10;
//
//    // create figures on our first invocation
//    if (!transmissionRing) {
//        auto color = cFigure::GOOD_DARK_COLORS[getId() % cFigure::NUM_GOOD_DARK_COLORS];
//
//        transmissionRing = new cRingFigure(("Host" + std::to_string(getIndex()) + "Ring").c_str());
//        transmissionRing->setOutlined(false);
//        transmissionRing->setFillColor(color);
//        transmissionRing->setFillOpacity(0.25);
//        transmissionRing->setFilled(true);
//        transmissionRing->setVisible(false);
//        //transmissionRing->setZIndex(-1);
//        canvas->addFigure(transmissionRing);
//
//        for (int i = 0; i < numCircles; ++i) {
//            auto circle = new cOvalFigure(("Host" + std::to_string(getIndex()) + "Circle" + std::to_string(i)).c_str());
//            circle->setFilled(false);
//            circle->setLineColor(color);
//            circle->setLineOpacity(0.75);
//            circle->setLineWidth(circleLineWidth);
//            circle->setZoomLineWidth(true);
//            circle->setVisible(false);
//            //circle->setZIndex(-0.5);
//            transmissionCircles.push_back(circle);
//            canvas->addFigure(circle);
//        }
//    }
//
//    if (lastPacket) {
//        // update transmission ring and circles
//        //if (transmissionRing->getAssociatedObject() != lastPacket) {
//            //transmissionRing->setAssociatedObject(lastPacket);
//            f//or (auto c : transmissionCircles)
//                //c->setAssociatedObject(lastPacket);
//        //}
//
//        simtime_t now = simTime();
//        simtime_t frontTravelTime = now - lastPacket->getSendingTime();
//        simtime_t backTravelTime = now - (lastPacket->getSendingTime() + lastPacket->getDuration());
//
//        // conversion from time to distance in m using speed
//        double frontRadius = frontTravelTime.dbl() * propagationSpeed;
//        //double frontRadius = std::min(ringMaxRadius, frontTravelTime.dbl() * propagationSpeed);
//        double backRadius = backTravelTime.dbl() * propagationSpeed;
//        double circleRadiusIncrement = circlesMaxRadius / numCircles;
//
//        // update transmission ring geometry and visibility/opacity
//        double opacity = 1.0;
//        if (backRadius > ringMaxRadius) {
//            transmissionRing->setVisible(false);
//            transmissionRing->setAssociatedObject(nullptr);
//        }
//        else {
//            transmissionRing->setVisible(true);
//            transmissionRing->setBounds(cFigure::Rectangle(x - frontRadius, y - frontRadius, 2*frontRadius, 2*frontRadius));
//            transmissionRing->setInnerRadius(std::max(0.0, std::min(ringMaxRadius, backRadius)));
//            if (backRadius > 0)
//                opacity = std::max(0.0, 1.0 - backRadius / circlesMaxRadius);
//        }
//
//        transmissionRing->setLineOpacity(opacity);
//        transmissionRing->setFillOpacity(opacity/5);
//
//        // update transmission circles geometry and visibility/opacity
//        double radius0 = std::fmod(frontTravelTime.dbl() * propagationSpeed, circleRadiusIncrement);
//        for (int i = 0; i < (int)transmissionCircles.size(); ++i) {
//            double circleRadius = std::min(ringMaxRadius, radius0 + i * circleRadiusIncrement);
//            if (circleRadius < frontRadius - circleRadiusIncrement/2 && circleRadius > backRadius + circleLineWidth/2) {
//                transmissionCircles[i]->setVisible(true);
//                transmissionCircles[i]->setBounds(cFigure::Rectangle(x - circleRadius, y - circleRadius, 2*circleRadius, 2*circleRadius));
//                transmissionCircles[i]->setLineOpacity(std::max(0.0, 0.2 - 0.2 * (circleRadius / circlesMaxRadius)));
//            }
//            else
//                transmissionCircles[i]->setVisible(false);
//        }
//
//        // compute animation speed
//        double animSpeed = idleAnimationSpeed;
//        if ((frontRadius >= 0 && frontRadius < circlesMaxRadius) || (backRadius >= 0 && backRadius < circlesMaxRadius))
//            animSpeed = transmissionEdgeAnimationSpeed;
//        if (frontRadius > circlesMaxRadius && backRadius < 0)
//            animSpeed = midtransmissionAnimationSpeed;
//        canvas->setAnimationSpeed(animSpeed, this);
//    }
//    else {
//        // hide transmission rings, update animation speed
//        if (transmissionRing->getAssociatedObject() != nullptr) {
//            transmissionRing->setVisible(false);
//            transmissionRing->setAssociatedObject(nullptr);
//
//            for (auto c : transmissionCircles) {
//                c->setVisible(false);
//                c->setAssociatedObject(nullptr);
//            }
//            canvas->setAnimationSpeed(idleAnimationSpeed, this);
//        }
//    }
//
//    // update host appearance (color and text)
//    getDisplayString().setTagArg("t", 2, "#808000");
//    if (state == IDLE) {
//        getDisplayString().setTagArg("i", 1, "");
//        getDisplayString().setTagArg("t", 0, "");
//    }
//    else if (state == TRANSMIT) {
//        getDisplayString().setTagArg("i", 1, "yellow");
//        getDisplayString().setTagArg("t", 0, "TRANSMIT");
//    }
}

double Host::getMinEndTOff()
{
    double minEndTOff = installedChannels[0][2];
    for (int i =0; i < nbOfChannels; i++)
    {
        if (installedChannels[i][2] < minEndTOff)
            minEndTOff = installedChannels[i][2];
    }
    return minEndTOff;
}

void Host::printInstalledChannelsTable()
{
    for (int i=0; i<nbOfChannels;i++)
    {
        for(int j=0; j<3;j++)
        {
            EV << "| " << installedChannels[i][j] ;
        }
        EV << endl;
    }
}

void Host::finish()
{
    // Check if the summary has already been printed
    static bool summaryPrinted = false;
    if (!summaryPrinted) {

        int numHosts = getParentModule()->par("numHosts");

        // Print summary information for connected hosts per server and SF
        for (auto& serverSF : hostsPerServerPerSF) {
            int serverIndex = serverSF.first;
            for (int sf = 7; sf <= 12; ++sf) { // Iterate over all possible spreading factors
                int numOfHosts = 0; // Initialize the number of hosts to zero
                // Check if there are hosts connected at this spreading factor for this server
                if (serverSF.second.count(sf) > 0) {
                    numOfHosts = serverSF.second[sf]; // Get the count of hosts
                }
                double percentage = (static_cast<double>(numOfHosts) / numHosts) * 100.0;
                EV_INFO << "Server[" << serverIndex << "]: Number of connected hosts at SF" << sf << " = " << numOfHosts << endl;
                EV_INFO << "Server[" << serverIndex << "]: Percentage of connected hosts at SF" << sf << " = " << percentage << "%" << endl;
                // Record scalar value for the number of hosts per spreading factor for each server
                char buf[64];
                sprintf(buf, "numOfHostsPerSF_Server%d_SF%d", serverIndex, sf);
                recordScalar(buf, numOfHosts);

            }
        }


        for (auto& pair : connectedHostsPerServer) {
            int serverIndex = pair.first->getIndex();
            int numOfConnectedHosts = pair.second.size();
            double percentage = (static_cast<double>(numOfConnectedHosts) / numHosts) * 100.0;
            EV_INFO << "Server[" << serverIndex << "]: Number of connected hosts = " << numOfConnectedHosts << endl;
            EV_INFO << "Server[" << serverIndex << "]: Percentage of connected hosts = " << percentage << "%" << endl;
        }

        // Print summary information for hosts not covered by any server
        EV_INFO << "Number of hosts not covered by any server: " << hostsNotCoveredByAnyServer.size() << endl;
        double percentageNotCoveredByAnyServer = (static_cast<double>(hostsNotCoveredByAnyServer.size()) / numHosts) * 100.0;
        EV_INFO << "Percentage of hosts not covered by any server: " << percentageNotCoveredByAnyServer << "%" << endl;

        // Mark the summary as printed
        summaryPrinted = true;
    }
}





}; //namespace
